
const root = document.getElementById('root');

root.innerHTML = `
<h2>Bank Dashboard</h2>
<input id="acc" placeholder="Account ID"/>
<input id="amt" placeholder="Amount"/>
<button onclick="deposit()">Deposit</button>
`;

async function deposit() {
  await fetch('http://localhost:5000/deposit', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      accountId: document.getElementById('acc').value,
      amount: Number(document.getElementById('amt').value)
    })
  });
}
