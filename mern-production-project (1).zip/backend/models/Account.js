
const mongoose = require('mongoose');

const schema = new mongoose.Schema({
  accountId: { type: String, unique: true },
  holderName: String,
  balance: Number,
  version: { type: Number, default: 0 }
});

module.exports = mongoose.model('Account', schema);
