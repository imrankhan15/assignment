
const Account = require('../models/Account');
const retry = require('../utils/retry');

exports.deposit = (accountId, amount) => retry(async () => {
  const acc = await Account.findOne({ accountId });
  const updated = await Account.findOneAndUpdate(
    { accountId, version: acc.version },
    { $set: { balance: acc.balance + amount, version: acc.version + 1 }},
    { new: true }
  );
  if (!updated) throw new Error("Conflict");
  return updated;
});

exports.withdraw = (accountId, amount) => retry(async () => {
  const acc = await Account.findOne({ accountId });
  if (acc.balance < amount) throw new Error("Insufficient");
  const updated = await Account.findOneAndUpdate(
    { accountId, version: acc.version, balance: { $gte: amount }},
    { $set: { balance: acc.balance - amount, version: acc.version + 1 }},
    { new: true }
  );
  if (!updated) throw new Error("Conflict");
  return updated;
});

exports.transfer = async (fromId, toId, amount) => {
  const session = await require('mongoose').startSession();
  session.startTransaction();
  try {
    const Account = require('../models/Account');
    const from = await Account.findOne({ accountId: fromId }).session(session);
    const to = await Account.findOne({ accountId: toId }).session(session);

    if (from.balance < amount) throw new Error("Insufficient");

    from.balance -= amount;
    to.balance += amount;
    from.version++;
    to.version++;

    await from.save();
    await to.save();

    await session.commitTransaction();
    return { from, to };
  } catch (e) {
    await session.abortTransaction();
    throw e;
  } finally {
    session.endSession();
  }
};
