
const express = require('express');
const http = require('http');
const mongoose = require('mongoose');
const cors = require('cors');
const { Server } = require('socket.io');
const service = require('./services/transactionService');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/bank');

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.post('/deposit', async (req, res) => {
  try {
    const r = await service.deposit(req.body.accountId, req.body.amount);
    io.emit("balance:updated", r);
    res.json(r);
  } catch (e) {
    io.emit("transaction:failed", e.message);
    res.status(400).json({ error: e.message });
  }
});

app.post('/withdraw', async (req, res) => {
  try {
    const r = await service.withdraw(req.body.accountId, req.body.amount);
    io.emit("balance:updated", r);
    res.json(r);
  } catch (e) {
    io.emit("transaction:failed", e.message);
    res.status(400).json({ error: e.message });
  }
});

app.post('/transfer', async (req, res) => {
  try {
    const r = await service.transfer(req.body.fromId, req.body.toId, req.body.amount);
    io.emit("balance:updated", r);
    res.json(r);
  } catch (e) {
    io.emit("transaction:failed", e.message);
    res.status(400).json({ error: e.message });
  }
});

server.listen(5000, () => console.log("Server running on 5000"));
