
# Production-Level Concurrent Banking System

## Features
- Optimistic Concurrency Control (versioning)
- Retry mechanism for conflicts
- Deposit, Withdraw, Transfer
- MongoDB transactions
- Socket.io real-time updates
- Load testing ready

## Run Backend
cd backend
npm install
npm start

## Run Frontend
cd frontend
npm install
npm start

## Concurrency Strategy
Uses version field + retry mechanism to prevent race conditions.

## Load Testing
Use k6 with 1000 virtual users.

## Architecture
Client → API → Service → DB
